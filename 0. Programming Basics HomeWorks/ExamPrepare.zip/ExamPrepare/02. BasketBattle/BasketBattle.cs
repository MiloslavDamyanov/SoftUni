﻿using System;
using System.Collections.Generic;

class BasketBattle
{
    static void Main()
    {
        string name = Console.ReadLine();
        int rounds = int.Parse(Console.ReadLine());
        int points = 0;
        string information = null;
        List<int> scores = new List<int>();
        List<string> info = new List<string>();
        int oddSum = 0;
        int evenSum = 0;

        


        
    }
}