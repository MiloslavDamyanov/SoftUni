﻿using System;

class PrintFirstLastName
{
    static void Main()
    {
        string firstName = "John";
        string lastName = "Smith";

        Console.WriteLine("{0} {1}", firstName, lastName);
    }
}