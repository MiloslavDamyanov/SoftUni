﻿using System;

class FloatOrDouble
{
    static void Main()
    {
        double doubleValue = 34.567839023;
        double anotherDouble = 8923.1234857;
        float floatValue = 12.345F;
        float anotherFloat = 3456.091F;

        Console.WriteLine(doubleValue);
        Console.WriteLine(anotherDouble);
        Console.WriteLine(floatValue);
        Console.WriteLine(anotherFloat);
    }
}
