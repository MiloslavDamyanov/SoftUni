﻿using System;

class VariableInHexFormat
{
    static void Main()
    {
        int hex = 0xFE;
        Console.WriteLine(hex);
    }
}