﻿using System;

class BooleanVariable
{
    static void Main()
    {
        bool isFemale = false;
        Console.WriteLine(isFemale);
    }
}