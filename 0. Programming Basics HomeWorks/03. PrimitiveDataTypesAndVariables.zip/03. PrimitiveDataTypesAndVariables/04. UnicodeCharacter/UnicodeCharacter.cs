﻿using System;

class UnicodeCharacter
{
    static void Main()
    {
        char asterisk = '\u002A';
        Console.WriteLine(asterisk);
    }
}