﻿using System;

class PrintNumbers
{
    static void Main()
    {
        Console.WriteLine("1");
        Console.WriteLine("101");
        Console.WriteLine("1001");

        // int firstNum = 1;
        // int secondNum = 101;
        // int thirdNum = 1001;
        // Console.WriteLine("{0}\n{1}\n{2}", firstNum, secondNum, thirdNum);
           
        // Console.WriteLine("1\n101\n1001");
           
        // int[] numbers = new int[] { 1, 101, 1001 };
        // foreach (var num in numbers)
        // {
        //     Console.WriteLine(num);
        // }
    }
}
